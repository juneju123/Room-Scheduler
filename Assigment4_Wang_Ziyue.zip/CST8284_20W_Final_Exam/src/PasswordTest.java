//Wang ziyue 040919399

import java.util.Scanner;

public class PasswordTest {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter password:");
		String passwd = input.next();
		Password password = new Password(passwd);
		int outputInt = doEncryption(password);
		System.out.print(outputInt);

	}
public static int doEncryption(Password password) {
	String firstResult = password.first(password.getPassword());
	return password.second(firstResult);

	
}
}
