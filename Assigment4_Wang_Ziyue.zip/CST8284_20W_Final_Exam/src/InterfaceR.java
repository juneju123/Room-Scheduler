
public interface InterfaceR {
	int second(String convertedPassword);
}
