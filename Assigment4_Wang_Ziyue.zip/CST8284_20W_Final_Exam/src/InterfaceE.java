
public interface InterfaceE {
	String first(String password);
}
