import java.util.ArrayList;

public class Password  extends AbstractPassword{
	String password;
	public Password(String passWord) {
		setPassword(passWord);
	}
	public String first(String password) {
		int nextChar;
		ArrayList<Character> charList = new ArrayList<Character>();
		for (int i = 0; i < password.length(); i++) {
			char c = password.charAt(i);
			nextChar = c+1;
			charList.add(password.charAt(i));
			charList.add((char)nextChar);
		}
		String result = "";
		for (int j = 0; j<charList.size(); j++) {
			result += charList.get(j);
		}
		return result;
	}
	public int  second(String convertedPassword) {
		int sum=1;
		for (int i=0; i<convertedPassword.length(); i++) {
			char c = convertedPassword.charAt(i);
			int ascii = (int)c;
			sum = sum * ascii;
		}
		int result = sum % 128;
		return result;
	}
}
